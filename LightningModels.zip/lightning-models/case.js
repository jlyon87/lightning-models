var models = (function Case(models) {

	var initCase = function() {
		return {
			sobjectType: "Case",
		};
	};

	models.initCase = initCase;

	return models;
})(models || {});