var models = (function Contact(models) {

	var initContact = function() {
		return {
			sobjectType: "Contact",
		};
	};

	models.initContact = initContact;

	return models;
})(models || {});